import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),"..");
const read=file=>fs.readFileSync(path.join(root,file),"utf8");
const assert=(condition,message)=>{if(!condition)throw new Error(message);};

const manifest=JSON.parse(read("data/manifest.json"));
const ids=new Set();
let total=0;
for(let chapter=1;chapter<=50;chapter+=1){
  const file=manifest.chapterFiles[String(chapter)];
  assert(file,"Manifest tidak memiliki Bab "+chapter);
  const rows=JSON.parse(read("data/"+file));
  assert(rows.length===manifest.chapterCounts[String(chapter)],"Jumlah item Bab "+chapter+" tidak sesuai manifest");
  for(const item of rows){
    const id=String(item?.id||"");
    assert(id,"Item tanpa ID di Bab "+chapter);
    assert(!ids.has(id),"ID duplikat: "+id);
    assert(Number(item.chapterNumber)===chapter,"chapterNumber salah: "+id);
    assert(String(item.indonesia||"").trim(),"Arti Indonesia kosong: "+id);
    assert(String(item.kanji||item.kana||item.displayTerm||"").trim(),"Teks Jepang kosong: "+id);
    ids.add(id);total+=1;
  }
}
assert(total===manifest.totalItems,"Total item tidak sesuai manifest");

const html=read("index.html");
assert(!/<style\b/i.test(html),"Masih ada CSS inline");
assert(!/<script\b(?![^>]*\bsrc=)/i.test(html),"Masih ada JavaScript inline");
for(const match of html.matchAll(/(?:src|href)="([^"]+)"/g)){
  const value=match[1];
  if(/^(?:https?:|data:|#)/.test(value))continue;
  const clean=value.replace(/[?#].*$/,"");
  assert(fs.existsSync(path.resolve(root,clean)),"Path lokal tidak ditemukan: "+value);
}

const css=read("assets/css/app.css");
let mode="code",quote="",escaped=false,depth=0;
for(let index=0;index<css.length;index+=1){
  const char=css[index],next=css[index+1]||"";
  if(mode==="comment"){
    if(char==="*"&&next==="/"){mode="code";index+=1;}
  }else if(mode==="string"){
    if(escaped)escaped=false;
    else if(char==="\\")escaped=true;
    else if(char===quote)mode="code";
  }else if(char==="/"&&next==="*"){mode="comment";index+=1;}
  else if(char==="'"||char==='"'){mode="string";quote=char;}
  else if(char==="{")depth+=1;
  else if(char==="}"){depth-=1;assert(depth>=0,"Kurung CSS berlebih");}
}
assert(mode==="code"&&depth===0,"CSS tidak seimbang");

function checkJavaScript(file,isModule=false){
  const source=read(file);
  const args=isModule?["--input-type=module","--check"]:["--check",path.join(root,file)];
  const result=spawnSync(process.execPath,args,{input:isModule?source:undefined,encoding:"utf8"});
  assert(result.status===0,"Syntax error "+file+": "+(result.stderr||result.stdout));
}
checkJavaScript("assets/js/critical.js");
checkJavaScript("assets/js/enhancements.js");
checkJavaScript("assets/js/data-loader.js",true);
checkJavaScript("assets/js/app.js",true);
checkJavaScript("sw.js");

console.log(JSON.stringify({status:"PASS",chapters:50,items:total,uniqueIds:ids.size,inlineStyles:0,inlineScripts:0}));
