const VOCABULARY = [];

const manifestUrl = new URL("../../data/manifest.json", import.meta.url);
const referenceUrl = new URL("../../data/reference-static.json", import.meta.url);
let manifest = null;
let referenceStatic = null;
let initializePromise = null;
const loadedChapters = new Set();
const chapterRequests = new Map();
const activeRangeChapters = new Map();

async function requestJson(url) {
  const response = await fetch(url, { credentials: "same-origin" });
  if (!response.ok) throw new Error(`HTTP ${response.status} untuk ${url.pathname}`);
  return response.json();
}

function chapterNumbers(label = "") {
  const values = [...String(label).matchAll(/\d+/g)].map(match => Number(match[0]));
  if (values.length === 2) {
    const [start, end] = values;
    return Array.from({ length: Math.max(0, end - start + 1) }, (_, index) => start + index);
  }
  return values.length === 1 ? [values[0]] : [];
}

function storage() {
  return window.WIKARU_STORAGE || window.localStorage;
}

function rangeStorageKey(label) {
  return `wikaru_lazy_range_${String(label).replace(/[^0-9-]/g, "")}`;
}

function activeRangeChapter(label) {
  const numbers = chapterNumbers(label);
  if (!numbers.length) return null;
  if (numbers.length === 1) return numbers[0];
  if (activeRangeChapters.has(label)) return activeRangeChapters.get(label);
  let stored = null;
  try { stored = Number(storage().getItem(rangeStorageKey(label))); } catch (_) {}
  const value = numbers.includes(stored) ? stored : numbers[0];
  activeRangeChapters.set(label, value);
  return value;
}

function setActiveRangeChapter(label, number) {
  const numbers = chapterNumbers(label);
  const value = Number(number);
  if (!numbers.includes(value)) return false;
  activeRangeChapters.set(label, value);
  try { storage().setItem(rangeStorageKey(label), String(value)); } catch (_) {}
  return true;
}

function addVocabulary(items) {
  const known = new Set(VOCABULARY.map(item => String(item?.id || "")));
  for (const item of items || []) {
    const id = String(item?.id || "");
    if (!id || known.has(id)) continue;
    VOCABULARY.push(item);
    known.add(id);
  }
  window.__WIKARU_VOCABULARY = VOCABULARY;
}

async function loadChapter(number) {
  const chapter = Number(number);
  if (!Number.isInteger(chapter) || chapter < 1 || chapter > 50) return [];
  if (loadedChapters.has(chapter)) return VOCABULARY.filter(item => Number(item.chapterNumber) === chapter);
  if (chapterRequests.has(chapter)) return chapterRequests.get(chapter);
  const request = (async () => {
    const file = manifest?.chapterFiles?.[chapter];
    if (!file) throw new Error(`Berkas Bab ${chapter} tidak terdaftar`);
    const items = await requestJson(new URL(`../../data/${file}`, import.meta.url));
    if (!Array.isArray(items)) throw new Error(`Format data Bab ${chapter} tidak valid`);
    addVocabulary(items);
    loadedChapters.add(chapter);
    document.dispatchEvent(new CustomEvent("wikaru:chapter-loaded", { detail: { chapter, count: items.length } }));
    return items;
  })().finally(() => chapterRequests.delete(chapter));
  chapterRequests.set(chapter, request);
  return request;
}

async function loadChapters(numbers) {
  const queue = [...new Set((numbers || []).map(Number).filter(number => Number.isInteger(number) && number >= 1 && number <= 50))];
  const results = [];
  let cursor = 0;
  const workers = Array.from({ length: Math.min(4, queue.length) }, async () => {
    while (cursor < queue.length) {
      const number = queue[cursor++];
      results.push(...await loadChapter(number));
    }
  });
  await Promise.all(workers);
  return results;
}

async function initialize() {
  if (initializePromise) return initializePromise;
  initializePromise = (async () => {
    [manifest, referenceStatic] = await Promise.all([requestJson(manifestUrl), requestJson(referenceUrl)]);
    if (manifest.extrasFile) addVocabulary(await requestJson(new URL(`../../data/${manifest.extrasFile}`, import.meta.url)));
    let savedSetup = null;
    try { savedSetup = JSON.parse(storage().getItem("minna_bab23_settings") || "null"); } catch (_) {}
    const savedChapter = String(savedSetup?.chapter || "Bab 31");
    const initial = activeRangeChapter(savedChapter) || 31;
    await loadChapters([...new Set([31, initial])]);
    window.WIKARU_DATA = WIKARU_DATA;
    return WIKARU_DATA;
  })();
  return initializePromise;
}

async function loadSelection(setup = {}) {
  await initialize();
  const label = String(setup.chapter || "");
  const numbers = chapterNumbers(label);
  if (!numbers.length) return [];
  const target = numbers.length > 1 ? activeRangeChapter(label) : numbers[0];
  return loadChapters([target]);
}

function normalizeCategory(value = "") {
  const raw = String(value || "").trim();
  return raw.toLowerCase() === "kata-kata referensi dan informasi" ? "Kata-Kata Referensi dan Informasi" : raw;
}

function catalogRows(book, materialCategory) {
  if (!manifest) return [];
  const category = normalizeCategory(materialCategory);
  return manifest.catalog.filter(row => (!book || row.book === book) && (!category || normalizeCategory(row.materialCategory) === category));
}

function books(additional = []) {
  const values = new Set([...(manifest?.catalog || []).map(row => row.book), ...(additional || [])].filter(Boolean));
  return [...values].sort((a, b) => a.includes(" II") - b.includes(" II") || a.localeCompare(b));
}

function materialsFor(book) {
  return [...new Set(catalogRows(book).map(row => normalizeCategory(row.materialCategory)))];
}

function chaptersFor(book, materialCategory) {
  return [...new Set(catalogRows(book, materialCategory).map(row => Number(row.chapterNumber)))].filter(Number.isFinite).sort((a, b) => a - b);
}

function quizChaptersFor(setup = {}) {
  const requested = chapterNumbers(setup.chapter);
  if (!requested.length) return chaptersFor(setup.book, setup.materialCategory);
  if (String(setup.chapter) === "Bab 1-50" && normalizeCategory(setup.materialCategory) === "Materi Umum") {
    return requested.filter(number => (manifest?.catalog || []).some(row => Number(row.chapterNumber) === number && normalizeCategory(row.materialCategory) === "Materi Umum"));
  }
  const available = new Set(chaptersFor(setup.book, setup.materialCategory));
  return requested.filter(number => available.has(number));
}

function totalForSelection(setup = {}) {
  if (!manifest) return 0;
  const requested = new Set(chapterNumbers(setup.chapter));
  const material = normalizeCategory(setup.materialCategory);
  return manifest.catalog.reduce((total, row) => {
    if (!requested.has(Number(row.chapterNumber))) return total;
    if (normalizeCategory(row.materialCategory) !== material) return total;
    if (String(setup.chapter) !== "Bab 1-50" && setup.book && row.book !== setup.book) return total;
    return total + Number(row.count || 0);
  }, 0);
}

function staticValue(name) {
  return referenceStatic?.values?.[name] ?? null;
}

function liveDataset(name) {
  const ids = () => referenceStatic?.datasets?.[name] || [];
  const current = () => {
    const byId = new Map(VOCABULARY.map(item => [String(item?.id || ""), item]));
    return ids().map(id => byId.get(String(id))).filter(Boolean);
  };
  return new Proxy([], {
    get(_target, property) {
      const data = current();
      if (property === Symbol.iterator) return data[Symbol.iterator].bind(data);
      const value = Reflect.get(data, property);
      return typeof value === "function" ? value.bind(data) : value;
    },
    has(_target, property) { return property in current(); },
    ownKeys() { return Reflect.ownKeys(current()); },
    getOwnPropertyDescriptor(_target, property) {
      return Object.getOwnPropertyDescriptor(current(), property) || { configurable: true, enumerable: false, writable: false, value: undefined };
    }
  });
}

function isChapterLoaded(number) {
  return loadedChapters.has(Number(number));
}

function registerServiceWorker() {
  if (!("serviceWorker" in navigator) || !/^https?:$/.test(location.protocol)) return;
  window.addEventListener("load", () => {
    navigator.serviceWorker.register(new URL("../../sw.js", import.meta.url)).catch(error => console.info("Cache offline tidak aktif:", error?.message || error));
  }, { once: true });
}

const WIKARU_DATA = {
  initialize,
  loadChapter,
  loadChapters,
  loadSelection,
  books,
  materialsFor,
  chaptersFor,
  quizChaptersFor,
  totalForSelection,
  activeRangeChapter,
  setActiveRangeChapter,
  isChapterLoaded,
  liveDataset,
  staticValue,
  registerServiceWorker,
  get manifest() { return manifest; },
  get loadedChapters() { return [...loadedChapters].sort((a, b) => a - b); }
};

export { WIKARU_DATA, VOCABULARY };
